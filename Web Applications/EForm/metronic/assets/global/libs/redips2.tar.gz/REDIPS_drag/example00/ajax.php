<!-- used in AJAX version -->
<table>
	<colgroup>
		<col width="100"/>
		<col width="100"/>
		<col width="100"/>
	</colgroup>
	<tbody>
		<tr>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td></td>
		</tr>
	</tbody>
</table>