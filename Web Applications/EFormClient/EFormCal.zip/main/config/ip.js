//const server = 'https://meditek.redimed.com.au'
const server = 'http://localhost'

const ip = {
    EFormServer: server+':3015'
}

export default ip